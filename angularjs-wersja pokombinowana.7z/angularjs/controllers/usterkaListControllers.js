// JavaScript source code
// rozszerzenie kontrolera usterka o modu� log�w
(function (angular) {
    /*    <div ng-controller="LogController">
          <p>Reload this page with open console, enter text and hit the log button...</p>
          <label>
Message:
                <input type="text" ng-model="message" />
            </label>
            <button ng-click="$log.log(message)">log</button>
            <button ng-click="$log.warn(message)">warn</button>
            <button ng-click="$log.info(message)">info</button>
            <button ng-click="$log.error(message)">error</button>
            <button ng-click="$log.debug(message)">debug</button>
        </div>
*/
    'use strict';
    angular.module('usterka')
      .controller('LogController', ['$scope', '$log', function ($scope, $log) {
          $scope.$log = $log;
          $scope.message = '';
  }]);
})(window.angular);


angular.module("usterka")
    .controller("usterkaListCtrl", function ($scope) {

    });
