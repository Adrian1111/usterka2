﻿/// <reference path="../angular.js" />

angular.module("usterka")
.constant("dataUrl", "http://localhost:5500/task")
.controller("usterkaCtrl", function ($scope, $http, $location, dataUrl) {
   
    $scope.data = {};

    $http.get(dataUrl)
    .success(function (data) {
        $scope.data.task = data;
    })
    .error(function (error) {
        $scope.data.error = error;
    });

    $scope.sendTask = function (taskDetails) {
        var task = angular.copy(taskDetails);
        console.log(taskDetails);
        $http.post(dataUrl, task)
        .success(function (data) {
            $scope.data.taskId = data.id;
            console.log("dobrze!");
        })
        .error(function (error) {
            $scope.data.taskError = error;
            console.log("dupa!" + JSON.stringify(error));
        })
        .finally(function () {
            console.log("No i pięknie dodałeś rekord o id " + $scope.data.taskId);
            $location.path("#");
        });
    }




    //predicate - domyślne sortowanie
    $scope.predicate = 'date';
    $scope.reverse = true;
    $scope.order = function (predicate) {
        $scope.reverse = ($scope.predicate === predicate) ? !$scope.reverse : false;
        $scope.predicate = predicate;
        // przekazanie statusu sortowania tablicy
        // console.log('predicate: ' + $scope.predicate + ' reverse: ' + $scope.reverse);
    };

});
